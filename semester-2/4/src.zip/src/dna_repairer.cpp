////////////////////////////////////////////////////////////////////////////////
// Module Name:  dna_repairer.h/cpp
// Authors:      Leonid Dworzanski, Sergey Shershakov
// Version:      0.2.0
// Date:         06.02.2017
// Copyright (c) The Team of "Algorithms and Data Structures" 2014–2017.
//
// This is a part of the course "Algorithms and Data Structures" 
// provided by  the School of Software Engineering of the Faculty 
// of Computer Science at the Higher School of Economics.
////////////////////////////////////////////////////////////////////////////////


#include "dna_repairer.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>

using namespace std;        // допустимо писать в глобальном пространстве только в cpp-файлах!

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

//  Очень важно!!
//  Этот файл является лишь примером-подсказкой, который
//  показывает как обращаться со списком имея доступ лишь
//  к pPreHead.
//  Вы должны опираясь на его реализовать свое правильное решение.
//  Например в методе readFile не проверяется формат и не
//  возбуждаются исключения, а repairDNA делает вообще
//  неизвестно что!!!
//  Кроме того этот пример будет работать только если у вас
//  правильно реализован linked_list.h

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


// Когда мы вычленили кусочки цепочек ДНК из общей массы, они гарантированно
// будут цельными. Например, a1:C a2:G a3:T.
// В map ключом служит не id, а id + number
// первого элемента цельной цепочки.
// Тогда в нашем случае dnaMap["a1"] == a1:C a2:G a3:T.

void addToMap(DNARepairer::Id2DnaMap& dnaMap, DNARepairer::NodeDNA* it1, DNARepairer::NodeDNA* it2)
{
    DNARepairer::NodeDNA* temp;
    bool lock = true;
    while (lock)
    {
        temp = it1->next;
        string key = it1->next->value.id + std::to_string(it1->next->value.number);
        while (temp != it2 && temp->value.number + 1 == temp->next->value.number)
            temp = temp->next;

        if (temp == it2)
            lock = false;

        if (dnaMap[key] == nullptr)
            dnaMap[key] = new DNARepairer::DNAChain;

        dnaMap[key]->moveNodesAfter(dnaMap[key]->getPreHead(), it1, temp);
    }
}

void mapToStorage(DNARepairer::Id2DnaMap dnaMap, DNARepairer::ListOfDNAChains& storage)
{


}

void show(xi::LinkedList<DNAElement>& list)
{
    xi::Node<DNAElement>* last = list.getPreHead();
    while (last->next != nullptr)
    {
        cout << last->next->value.id << last->next->value.number << ":" << last->next->value.base << " ";
        last = last->next;
    }
    cout << endl;
}

void printMap(DNARepairer::Id2DnaMap dnaMap)
{
    for (auto i: dnaMap)
    {
        show(*i.second);
    }
}

void DNARepairer::repairDNA()
{
    Id2DnaMap dnaMap;
    NodeDNAChain* itOutter = _dnaStorage.getPreHead();

    // Inspect every DNA chain
    while (itOutter->next != nullptr)
    {
        itOutter = itOutter->next;


        NodeDNA* it1 = itOutter->value.getPreHead(); // pre-first element of a chain
        NodeDNA* it2 = it1;
        // Go through DNA chain
        while (it2->next != nullptr)
        {
            if (it2->next->value.id != it1->next->value.id)
            {
                addToMap(dnaMap, it1, it2);
                it2 = it1;
                continue;
            }
            it2 = it2->next;
        }
        addToMap(dnaMap, it1, it2);
    }
    printMap(dnaMap);
}

void DNARepairer::printDNAStorage()
{
    NodeDNAChain* itOutter = _dnaStorage.getPreHead();
    while (itOutter->next != nullptr)
    {
        itOutter = itOutter->next;
        NodeDNA* itInner = itOutter->value.getPreHead();

        while (itInner->next != nullptr)
        {
            itInner = itInner->next;
            cout << itInner->value.id << itInner->value.number
                 << ":" << itInner->value.base << " ";
        }

        cout << endl;
    }
}

void DNARepairer::readFile(const string& filename)
{
    ifstream fin(filename);

    if (!fin)
        throw std::runtime_error("Could not open file.");


    // начинаем с головы
    NodeDNAChain* it = _dnaStorage.getPreHead();

    string line;
    while (getline(fin, line))
    {
        // Создаем узел ДНК на куче
        NodeDNAChain* pNewNode = new NodeDNAChain;

        //Создаем строковый поток для разбора
        istringstream istr(line);

        string strTmp;
        while (istr >> strTmp)                                  // разбиваем поток на слова
        {
            DNAElement tmpDNAElement(strTmp);                   // каждое слово читаем в DNAElement
            pNewNode->value.addElementToEnd(tmpDNAElement);     // добавляем полученный DNAElement в ДНК            
        }
        it->next = pNewNode;
        it = it->next;

    }
}

DNARepairer::ListOfDNAChains& DNARepairer::getDNAStorage()
{
    return _dnaStorage;
}
