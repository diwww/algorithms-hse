#include "dna_element.h"
#include <string>

DNAElement::DNAElement()
{
    number = {};
    id = {};
    base = {};
}

DNAElement::DNAElement(const std::string& description)
{
    readFromString(description);
}

void DNAElement::readFromString(const std::string& description)
{
    // id
    id = description[0];
    // number
    size_t delimPos = description.find(':');
    std::string numberStr = description.substr(1, delimPos - 1);
    number = std::stoi(numberStr, nullptr); // throws invalid_argument
    // base
    // TODO: check A C T G (or enum)
    base = description.substr(delimPos + 1);
}
